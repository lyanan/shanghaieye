jQuery(document).ready(function($) {
	if ( $.fn.tokenize ) {
		$( '.vfb-autocomplete' ).tokenize();
	}
});