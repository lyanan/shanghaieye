jQuery(document).ready(function($) {
	if ( $.fn.clockpicker ) {
		$( '.vfb-clockpicker' ).clockpicker();
	}
});