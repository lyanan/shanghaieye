jQuery(document).ready(function($) {
	if ( $.fn.knob ) {
		$( '.vfb-knob' ).knob();
	}
});